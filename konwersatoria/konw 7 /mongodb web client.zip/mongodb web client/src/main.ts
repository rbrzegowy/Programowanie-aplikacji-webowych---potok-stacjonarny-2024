import api from './api'
import { EmailPassword } from './models/emailPassword.model'
// await api.loginAnonymous()
document.querySelector('#loginForm')?.addEventListener('submit', (ev) => {
  ev.preventDefault()
  login(ev.target as HTMLFormElement)
})

document.querySelector('#anonymousLogin')?.addEventListener('click', () => {
  login()
})
document.querySelector('#getNotes')?.addEventListener('click', getNotes)

async function getNotes() {
  const notesCollection = api.collection('notes')
  console.log(notesCollection)
  const notes = await notesCollection.find({})
  console.log(notes)
}

async function login(form?: HTMLFormElement) {
  if (form) {
    const formData = new FormData(form)
    const loginData = Object.fromEntries(formData.entries()) as EmailPassword
    return await api.login(loginData)
  } else {
    return await api.loginAnonymous()
  }
}

// await api.call(async (user: Realm.User) => {
//   const summed = await user.functions.sum(2, 3)
//   console.assert(summed === 5)
// })