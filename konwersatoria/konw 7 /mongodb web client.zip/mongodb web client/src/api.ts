import * as config from './atlasConfig.json'
import * as Realm from 'realm-web'
import { EmailPassword } from './models/emailPassword.model'

const DATABASE_NAME = 'notes'

class Api {
  private _user: Realm.User | undefined
  private mongo?: globalThis.Realm.Services.MongoDB

  public get user(): Realm.User | undefined {
    return this._user
  }
  public set user(value: Realm.User | undefined) {
    this._user = value
    this.getMongoClient()
  }

  // const collection = mongo.db(DATABASE_NAME).collection(COLLECTION_NAME);

  constructor(private app: Realm.App) {}

  private getMongoClient() {
    this.mongo = this.app.currentUser!.mongoClient(config.dataSourceName)
  }
  async loginAnonymous() {
    const credentials = Realm.Credentials.anonymous()
    this.user = await this.app.logIn(credentials)
    console.log('[mongo user]', this.user)
    return this.user
  }

  async login(emailPassword: EmailPassword) {
    const credentials = Realm.Credentials.emailPassword(emailPassword.email, emailPassword.password)
    this.user = await this.app.logIn(credentials)
    console.log('[mongo user]', this.user)
    return this.user
  }

  collection(name: string) {
    return this.mongo!.db(DATABASE_NAME).collection(name)
  }
}
const realmApp = new Realm.App({ id: config.appId, baseUrl: config.baseUrl })
const api = new Api(realmApp)

export default api