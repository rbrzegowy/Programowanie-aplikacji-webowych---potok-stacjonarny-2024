export type EmailPassword = {
  email: string,
  password: string
}