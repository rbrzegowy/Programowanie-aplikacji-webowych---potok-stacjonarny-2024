## Połączenie MongoDB z aplikacji webowej
Używamy usługi Realm do połączenia za pomocą Web SDK
1. Utwórz aplikację webową w MongoDB Atlas:  
https://www.mongodb.com/docs/atlas/app-services/apps/create/#std-label-create-a-realm-app
1. Zainstaluj klienta: https://www.mongodb.com/docs/atlas/device-sdks/web/install/
1. Wybierz metodę uwierzytelniania (Authentication Providers): https://services.cloud.mongodb.com/groups/649ae1072baeaa537cfe9153/apps/663d1f0d582388250518fac5/auth/providers
1. Połącz z aplikacją źródło danych: https://services.cloud.mongodb.com/groups/649ae1072baeaa537cfe9153/apps/663d1f0d582388250518fac5/dataSources
1. Wykonaj zapytania: https://www.mongodb.com/docs/atlas/device-sdks/web/mongodb/