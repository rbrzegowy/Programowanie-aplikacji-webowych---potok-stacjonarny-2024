import { Note } from "./note.models"

export type Notes = Note[]